// KickoffGate route-group layout.
// Keep this isolated: no global theme overrides here.
export default function GateLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
