import MatchEditor from "@/components/admin/MatchEditor";

export default function NewMatchPage() {
  return <MatchEditor mode="create" />;
}
