import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // samo za home
  if (pathname !== "/") return NextResponse.next();

  // preskoči ako već imamo cookie
  const seen = req.cookies.get("seenKickoff")?.value;
  if (seen === "1") return NextResponse.next();

  // redirect na kickoff pre renderovanja Home
  const url = req.nextUrl.clone();
  url.pathname = "/kickoff";
  return NextResponse.redirect(url);
}

export const config = {
  matcher: ["/"],
};